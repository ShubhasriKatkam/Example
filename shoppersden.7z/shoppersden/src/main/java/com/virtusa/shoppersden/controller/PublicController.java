package com.virtusa.shoppersden.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PublicController {

	@RequestMapping(value="/home", method = RequestMethod.GET)
    public ModelAndView home(){
		System.out.println("in controller........");
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("shoppershome");
        return modelAndView;
    }
	@GetMapping(value="/registration")
    public String register()
    {
        return "registration";
    }
    @RequestMapping("/login")
    public String login()
    {
        return "login";
    }
    @RequestMapping("/userhomepage")
    public String userhomepage()
    {
        return "userhomepage";
    }
    
    @RequestMapping("/account")
    public String account()
    {
        return "account";
    }
    @RequestMapping("/cart")
    public String cart()
    {
        return "Cart";
    }
    
    
}
 
    

