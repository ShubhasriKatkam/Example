package com.virtusa.lp.api.service;

import java.util.List;

import com.virtusa.lp.api.model.Account;
import com.virtusa.lp.api.model.Customer;

public interface CustomerManager {
	public void save(Object cust);

	public List<Account> getAccounts();
}
