package com.virtusa.lp.api.repo;

public abstract class BaseDao {

}
