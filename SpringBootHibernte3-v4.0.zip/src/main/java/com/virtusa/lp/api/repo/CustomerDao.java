package com.virtusa.lp.api.repo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.virtusa.lp.api.model.Account;
import com.virtusa.lp.api.model.Customer;

@Repository
public class CustomerDao extends BaseDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	public void save(Object cust) {
		Session session = sessionFactory.getCurrentSession();
		session.saveOrUpdate(cust);
	}
	
	
	public List<Account> getAccounts() {
		Session session = sessionFactory.getCurrentSession();
		//Query query = session.createQuery("from Customer");
		
		//List<Customer> custs = query.list();
		List<Account> accts= session.createCriteria(Account.class).list();
		return accts;
	}
}
