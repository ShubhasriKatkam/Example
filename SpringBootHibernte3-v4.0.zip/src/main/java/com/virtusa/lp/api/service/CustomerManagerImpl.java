package com.virtusa.lp.api.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.virtusa.lp.api.model.Account;
import com.virtusa.lp.api.model.Customer;
import com.virtusa.lp.api.repo.CustomerDao;

@Service
@Transactional
public class CustomerManagerImpl implements CustomerManager {
	
	@Autowired
	private CustomerDao dao;

	@Override
	public void save(Object cust) {
		// TODO Auto-generated method stub
		dao.save(cust);
	}

	@Override
	public List<Account> getAccounts() {
		// TODO Auto-generated method stub
		return dao.getAccounts();
	}

}
