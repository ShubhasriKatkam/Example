package com.virtusa.lp.api.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.virtusa.lp.api.model.Account;
import com.virtusa.lp.api.model.Customer;
import com.virtusa.lp.api.service.CustomerManager;

@RestController
public class MyRestController {
	
	@Autowired
	private CustomerManager custService;
	
	@GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<Account>> getUserById(@PathVariable("id") int id) {
		
		List<Customer> lstCustomers = new ArrayList<>();
		
		List<Account> lstAccount = new ArrayList<>();
		
		
		Customer cust1 = new Customer();
		cust1.setEmail("aa@rrr.com");
		//cust1.setId(1);
		cust1.setName("New Virtusa"+ id);
		
		Customer cust2 = new Customer();
		cust2.setEmail("zz@rrr.com");
		//cust2.setId(2);
		cust2.setName("New Polaris" +id);
		
		Account act1 = new Account();
		act1.setAccountNumber("123456");
		act1.setType("Sav");
		
		Account act2 = new Account();
		act2.setAccountNumber("456789");
		act2.setType("Sav");
	
		
		act1.setCust(cust1);
		act2.setCust(cust1);
		
	
		custService.save(act1);
		custService.save(act2);
		
		lstAccount = custService.getAccounts();
		
        return new ResponseEntity<List<Account>>(lstAccount, HttpStatus.OK);
    }
}

