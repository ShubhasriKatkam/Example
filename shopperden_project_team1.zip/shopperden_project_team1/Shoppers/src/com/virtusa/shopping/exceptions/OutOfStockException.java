package com.virtusa.shopping.exceptions;

public class OutOfStockException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int qty;

    public OutOfStockException(int qty) {
        this.qty=qty;
    	System.out.println(qty);
        
    }
 

}