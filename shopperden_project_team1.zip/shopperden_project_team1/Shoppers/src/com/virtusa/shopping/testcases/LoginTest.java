package com.virtusa.shopping.testcases;
import static org.junit.Assert.*;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Collection;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;
import com.virtusa.shopping.Dao.CustomerDao;
import com.virtusa.shopping.implementations.CustomerDaoImpl;
import com.virtusa.shopping.models.Customer;
@RunWith(value=Parameterized.class)
public class LoginTest {
    private static Customer customer;    
    
      @Parameter(value = 0)
      public int roleId;
      @Parameter(value = 1)
      public String name;
      @Parameter(value = 2)
      public String address;
      @Parameter(value =3)
      public  String email;
      @Parameter(value = 4)
      public String password;
    @Parameter(value = 5)
      public Long phoneNo;
   
      
    @Parameters
    public static Collection getTestParameters() {
        return Arrays.asList(new Object[][] {{2,"Shubhasri","Hyderabad","shubhasri@gmail.com","Shubh@12",9966469588L}});}

 @BeforeClass
public static void createInstance()
{
    customer=new Customer ();
}

@Before
public void initializeUser()
{
    customer.setRoleId(roleId);
    customer.setName(name);
    customer.setAddress(address);
    customer.setEmail(email);
    customer.setPassword(password);
    customer.setPhoneNo(phoneNo);
    //mainuser.setRole_id(role_id);
}

@AfterClass
public static void deleteInstance()
{
    customer=null;
}
@Test
public void testCustomerId()
{
    //To check if customer role id is not null
    assertThat(customer.getRoleId(),is(notNullValue()));
  //To check if customer name is not null
    assertThat(customer.getName(),is(notNullValue()));
  //To check if customer email is not null
    assertThat(customer.getEmail(),is(notNullValue()));
  //To check if customer address is not null
    assertThat(customer.getAddress(),is(notNullValue()));
  //To check if customer password is not null
    assertThat(customer.getPassword(),is(notNullValue()));
  //To check if customer phoneno is not null
    assertThat(customer.getPhoneNo(),is(notNullValue()));
}
@Test
public void testPasswordPattern()
{
    
/*    To check the password that should contain 8 to 10 characters and it should contain Upper case and lowercase characters, numbers and special characters*/
    assertEquals(true, customer.getPassword().matches("(?=^.{8,10}$)(?=.*\\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&amp;*()_+}{&quot;&quot;:;'?/&gt;.&lt;,]).*$"));
    
}
 


}

