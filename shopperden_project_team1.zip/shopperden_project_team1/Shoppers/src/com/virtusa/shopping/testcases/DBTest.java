package com.virtusa.shopping.testcases;

import java.sql.Connection;
import java.sql.SQLException;

import org.junit.Test;

import com.virtusa.shopping.helpers.MySqlHelper;

import junit.framework.Assert;
	 
	    public class DBTest {
	        Connection connection;
	        
	        @SuppressWarnings("deprecation")
	        //To test the database is connection opened
	        @Test
	        public void isConnectionOpened() {
	            connection=MySqlHelper.getConnection();
	            Assert.assertNotNull("DB connection not created", connection);
	        }
	        
	        //To test the connection is closed
	        @Test
	        public void isConnectionClosed() throws SQLException {
	            connection=MySqlHelper.getConnection();
	            connection.close();
	            Assert.assertTrue(connection.isClosed());
	        }
	    }


