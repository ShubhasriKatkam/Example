
package com.virtusa.shopping.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.CartDao;
import com.virtusa.shopping.exceptions.OutOfStockException;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.ProductQty;

public class CartDaoImpl implements CartDao {
	final static Logger logger= Logger.getLogger(CartDaoImpl.class);
	
	private Connection conn;
	private PreparedStatement pre;
	private CallableStatement callable;
	private ResultSet rs ;
	private Statement st;
	int i;
	
	//To create a cart for registered customer
	@Override
	public int createCart(long phone) throws SQLException {
		// TODO Auto-generated method stub
		
		//connecting to mysql database
		    conn=MySqlHelper.getConnection();
		    pre=conn.prepareStatement("insert into cartteam1 (phoneNo) values(?)");
		    pre.setLong(1, phone);
		    i=pre.executeUpdate();		     
		    return i;
	}
	
	//To add products into cart
	@Override
	public int addToCart(ProductQty productQty) throws SQLException,OutOfStockException {
		int i =0;
		try {
			//connecting to mysql database
			conn = MySqlHelper.getConnection();	
			String query="select stock from productteam1 where productId="+productQty.getProductId();
            st = conn.createStatement();
            rs =st.executeQuery(query);
            rs.next();
            logger.info("Checking availablity of stock");
              
                if( productQty.getQty()> rs.getInt(1))
                {
                    throw new OutOfStockException(rs.getInt(1));   
                }
                               
               
			//calling store procedure for add products into the cart
			
            else
             {
            	
            	callable = conn.prepareCall("{call addproductqtyteam1(?,?,?,?,?)}");
            	callable.setInt(1, productQty.getQty());
            	callable.setDouble(2, productQty.getAmount());
            	callable.setInt(3, productQty.getCartId());
    			callable.setString(4, productQty.getCategoryId());
    			callable.setInt(5, productQty.getProductId());
    			logger.info("Adding product to cart........");
    			i =callable.executeUpdate();
			
		}
		}
		catch(SQLException e)
		{  
			logger.error("Error occured"+e.getMessage());
			System.out.println("Message : "+e);
		}
		
		finally
		{
			conn.close();
		}
		
	return i;	
		
	}
	
	//To update products in the cart based on qty
	@Override
	public int updateCart(ProductQty productQty) throws SQLException {
		// TODO Auto-generated method stub
		int i =0;
		try {
			//Connecting to mysql database
			conn = MySqlHelper.getConnection();	
			int productQtyId = productQty.getProductQtyId();
			pre = conn.prepareStatement("update productqtyteam1 set qty=? where productQtyId ="+productQtyId);
			pre.setInt(1, productQty.getQty());
			/*
			 * callable = conn.prepareCall("{call updateProductQty(?,?)}");
			 * callable.setInt(1, productQty.getQty()); callable.setDouble(2,
			 * productQty.getProductQtyId());
			 */
			i =pre.executeUpdate();
		}
		catch(SQLException e)
		{
			logger.error("Error occured"+e.getMessage());
			System.out.println("Message : "+e);
		}
		finally
		{
			conn.close();
		}
		
	return i;	
	}
	
	//To display all products in the cart 
	@Override
	public List<ProductQty> getCart(long phoneNo) throws SQLException {
		// TODO Auto-generated method stub
		  ProductQty productQty;
		  List<ProductQty> productQtyList=new ArrayList<ProductQty>();
		  try
		  {
			  conn = MySqlHelper.getConnection();
			  callable = conn.prepareCall("{call searchByCartId(?)}");
			  callable.setLong(1, phoneNo);
			  rs = callable.executeQuery();
			  logger.info("Fetching product details by cart ID");
			  while(rs.next())
			  {
				  productQty = new ProductQty();
				  productQty.setProductQtyId(rs.getInt(1));
				  productQty.setQty(rs.getInt(2));
				  productQty.setAmount(rs.getDouble(3));
				  productQty.setCartId(rs.getInt(4));
				  productQty.setCategoryId(rs.getString(5));
				  productQty.setProductId(rs.getInt(6));
				  productQtyList.add(productQty);
				
			  }
		  }
		  catch(SQLException e)
		  {   
			  logger.error("Error occured"+e.getMessage());
			  System.out.println("Exception : "+e);
		  }
		  finally
		  {
			  conn.close();
		  }
		
		return productQtyList;
	}
	//To delete product from cart based on productid
	@Override
	public int deleteCart(ProductQty productQty) {
		
		 int i=0;
	        long productId =0l;
	        //System.out.println(productId);
	        try 
	        { 
	            conn = MySqlHelper.getConnection();
	            productId = productQty.getProductId();
	            String sql="delete from productqtyteam1 where productId="+productId;
	            pre = conn.prepareStatement(sql);
	            
	           
	            i = pre.executeUpdate();
	           }
	        
	        catch(SQLException se)
	          {
	        	logger.error("Error occured"+se.getMessage());
	            System.out.println("Exception : "+se.getMessage());
	           }
	        finally
	        {
	            
	            try {
	                conn.close();
	            } catch (SQLException e) {
	            	logger.error("Error occured"+e.getMessage());
	                e.printStackTrace();
	            }
	        }
	        return i;
	        
		}

	@Override
	public int getCartId(long phoneNo) throws SQLException {
		
		  conn = MySqlHelper.getConnection();			  
		  pre =conn.prepareStatement("select cartId from cartteam1 where phoneNo ="+phoneNo);
		  rs = pre.executeQuery(); 
		  rs.next();
		  int cartId= rs.getInt(1);	
		  logger.info("Retrieving the cart ID");
		return cartId;
	}

	
		}