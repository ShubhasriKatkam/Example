package com.virtusa.shopping.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.ProductDao;
import com.virtusa.shopping.helpers.MySqlHelper;
import com.virtusa.shopping.models.Product;

public class ProductDaoImpl implements ProductDao
{

    private Connection conn;
    private PreparedStatement ps;
    private ResultSet rs; 
    private CallableStatement callable;
    List<Product> products=new ArrayList<Product>();
    final static Logger logger= Logger.getLogger(ProductDaoImpl.class);
	
    
    //To insert new product into the database
	@Override
	public int saveProductInfo(Product product) throws SQLException {
		// TODO Auto-generated method stub
		int i =0;
		try{	
			//Connecting to mysql database
		    conn = MySqlHelper.getConnection();		    
		    String sql="insert into productteam1(productName,productDesc,brandName,price,stock,image,categoryId) values(?,?,?,?,?,?,?)";		    
		    ps = conn.prepareStatement(sql);
		    //ps.setInt(1, product.getProductId());
		    
		    //Assigning the values from form to the database attributes
		    ps.setString(1, product.getProductName());
		    ps.setString(2, product.getProductDesc());
		    ps.setString(3, product.getBrandName());
		    ps.setDouble(4, product.getProductPrice());
		    ps.setInt(5, product.getStock());
		    ps.setString(6, product.getImage());
		    ps.setString(7, product.getCategory());
		    i = ps.executeUpdate();
		    logger.info("Storing product");
		   
		}catch(Exception se){
			logger.error("Error occured"+se.getMessage());
			System.out.println("Message  :" +se.getMessage());
		
		}
		finally {
			conn.close();
		}
	 return i;
	}
	
	//To  display all the products 
	@Override
	public List<Product> getAllProducts() throws SQLException {
		// TODO Auto-generated method stub
		Product product;
	       
	    try {
	    	//connecting to mysql database
	    	conn=MySqlHelper.getConnection();
	    	//Calling a store procedure to get all the products from database
	        callable=conn.prepareCall("{call selectAllProducts()}");
	        rs=callable.executeQuery(); 
	             
	       
	        while(rs.next())
	        {          	
	        	product = new Product();
	        	product.setProductId(rs.getInt(1));
	        	product.setProductName(rs.getString(2));
	        	product.setProductDesc(rs.getString(3));
	        	product.setBrandName(rs.getString(4));
	        	product.setProductPrice(rs.getDouble(5));
	        	product.setStock(rs.getInt(6));
	        	product.setImage(rs.getString(7));
	        	product.setCategory(rs.getString(8));
	            products.add(product);
	            
	        }
	        logger.info("Displaying all products");
	       
	    }catch(SQLException e) 
	    {
	    	logger.error("Error occured"+e.getMessage());
	    	e.printStackTrace();
	    	}
	    finally {
	        conn.close();
	    }
	      
	    return products;
	    }
	
	//To retrieve the products based on product id
	@Override
	public List<Product> getProductById(int productId) {
		// TODO Auto-generated method stub
		Product product = new Product();
		//System.out.println(productId);
		try 
		{
			//Connecting to mysql database
			conn = MySqlHelper.getConnection();
			//calling store procedure for retrieving the product details based on product id
			callable=conn.prepareCall("{call searchByProductId(?)}");
			callable.setLong(1,productId);
			rs=callable.executeQuery(); 
			while(rs.next()) {
				product.setProductId(rs.getInt(1));
				product.setProductName(rs.getString(2));
				product.setProductDesc(rs.getString(3));
				product.setBrandName(rs.getString(4));
				product.setProductPrice(rs.getDouble(5));
				product.setStock(rs.getInt(6));
				product.setImage(rs.getString(7));
				product.setCategory(rs.getString(8));
				products.add(product);
				}
			logger.info("Retrieving the products based on product id");
			
		}
		catch(SQLException se)
		{
			logger.error("Error occured"+se.getMessage());
			System.out.println("Exception : "+se.getMessage());
		}
		finally
		{
			
			try {
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				logger.error("Error occured"+e.getMessage());
				e.printStackTrace();
			}
		}
		return products;
		
	}
	
	//To update the product details based on product id
	public int updateProduct(Product product) {
        // TODO Auto-generated method stub
       //Product  product = new Product();
        int i=0;
        long productId =0l;
        //System.out.println(productId);
        try 
        { 
        	//connecting to mysql database
            conn = MySqlHelper.getConnection();
            productId = product.getProductId();
            String sql="update productteam1 set productId=?,productName=?,productDesc=?,brandName=?,price=?,stock=? where productId="+productId;
            ps = conn.prepareStatement(sql+";");
            ps.setInt(1, product.getProductId());
            ps.setString(2, product.getProductName());
            ps.setString(3, product.getProductDesc());           
            ps.setString(4, product.getBrandName());
            ps.setDouble(5, product.getProductPrice());
            ps.setInt(6, product.getStock());
            i = ps.executeUpdate();
            logger.info("Updating the product details based on product id");
           }
        
        catch(SQLException se)
          { 
        	logger.error("Error occured"+se.getMessage());
            System.out.println("Exception : "+se.getMessage());
           }
        finally
        {
            
            try {
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
            	logger.error("Error occured"+e.getMessage());
                e.printStackTrace();
            }
        }
        return i;
        
    }

	//To delete the product from database
	@Override
	public int deleteProduct(Product product) {
		   //Product  product = new Product();
        int i=0;
        long productId =0l;
        //System.out.println(productId);
        try 
        { 
        	//connecting to mysql database
            conn = MySqlHelper.getConnection();
            productId = product.getProductId();
            String sql="delete from productteam1 where productId="+productId;
            ps = conn.prepareStatement(sql);
            //ps.setInt(1, product.getProductId());
           
            i = ps.executeUpdate();
            logger.info("Delating the product from database");
           }
        
        catch(SQLException se)
          {
        	logger.error("Error occured"+se.getMessage());
            System.out.println("Exception : "+se.getMessage());
           }
        finally
        {
            
            try {
                conn.close();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
            	logger.error("Error occured"+e.getMessage());
                e.printStackTrace();
            }
        }
        return i;
        
	}
	}

	

