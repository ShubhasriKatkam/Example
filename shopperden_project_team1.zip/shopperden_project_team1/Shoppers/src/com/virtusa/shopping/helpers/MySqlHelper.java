package com.virtusa.shopping.helpers;

 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

 

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
public class MySqlHelper {
    
     private static Connection conn;
        private static Logger logger = Logger.getLogger(MySqlHelper.class);
          
        static {
            PropertyConfigurator.configure("C:\\Users\\graghu\\Documents\\Raghu\\shopperden_project_team1\\shopperden_project_team1\\Shoppers\\log4j.properties");
        }
    //For connecting to the mysql database
        
     public static Connection getConnection()
     {
         ResourceBundle rb=ResourceBundle.getBundle("com/virtusa/shopping/resources/db");
         
         //Assigning database username,password,url and driver
         String username=rb.getString("user");
         String password=rb.getString("password");
         String url=rb.getString("url");
         String drivername=rb.getString("driver");
         try {
             Class.forName(drivername);
             try {
            	 //Getting mysql connection
                 conn = DriverManager.getConnection(url, username, password);
             } catch (SQLException e) {
                 // TODO Auto-generated catch block
                 //e.printStackTrace();
                 logger.error("SQL Exception" + e.getMessage());
             }
         } catch (ClassNotFoundException e) {
             // TODO Auto-generated catch block
           
           //e.printStackTrace();
             logger.error("Class not found Exception" + e.getMessage());
         }
          
         return conn;
         
     }
}
 