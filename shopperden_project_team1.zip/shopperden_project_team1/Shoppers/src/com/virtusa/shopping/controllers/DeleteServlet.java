package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.ProductDao;
import com.virtusa.shopping.implementations.ProductDaoImpl;
import com.virtusa.shopping.models.Product;

/**
 * Servlet implementation class DeleteServlet
 */
//To delete products from the database
@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger= Logger.getLogger(DeleteServlet.class);
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		try {
			 //Fetching productId 
			 int pid = Integer.parseInt(request.getParameter("pid"));
			 Product product = new Product();
			 //binding productId to product Object
			 product.setProductId(pid);
			 //Assigning ProductImpl(c) reference to ProductDao(I)
			 ProductDao productdao = new ProductDaoImpl();
			 //deleting product from Product Table
			 int i = productdao.deleteProduct(product);
	         if(i>0)
	         { 
	        	 logger.info("Admin deleted product successfully");
	  		     out.println("<script>alert('Product deleted successfully');\nwindow.location.href='adminhome.jsp'</script>");
		  	 }
		  	 else
		  	  {
		  		logger.error("Admin Failed to delete Product");
		  	   out.println("<script>alert('Failed to delete Product');\nwindow.location.href='adminhome.jsp'</script>");
		  	   }
	           
	           
			} 
		catch (Exception e)
		{
			logger.error("Error occured"+e.getMessage());
			System.out.println(e.getMessage());
		}
		
		}
	}
