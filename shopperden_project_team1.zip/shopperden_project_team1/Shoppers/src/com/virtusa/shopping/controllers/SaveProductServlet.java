package com.virtusa.shopping.controllers;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.ProductDao;
import com.virtusa.shopping.implementations.ProductDaoImpl;
import com.virtusa.shopping.models.Product;


@MultipartConfig(fileSizeThreshold=1024*1024*2, 
maxFileSize=1024*1024*10, 
maxRequestSize=1024*1024*50)

//To add the new products into the database
@WebServlet("/SaveProductServlet")

public class SaveProductServlet extends HttpServlet
{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	final static Logger logger= Logger.getLogger(SaveProductServlet.class);
	
	//To store the image into the database
	private String getFileName(final Part part) {
	    
	    for (String content : part.getHeader("content-disposition").split(";")) {
	        if (content.trim().startsWith("filename")) {
	            return content.substring(
	                    content.indexOf('=') + 1).trim().replace("\"", "");
	        }
	    }
	    return null;
	}
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter outObj = response.getWriter();
		
		try {
			// fetching data from admin
			String pname = request.getParameter("pname");
			String pdesc = request.getParameter("desc");
			double price = Double.parseDouble(request.getParameter("price"));
			String bname = request.getParameter("bname");
            int stock = Integer.parseInt( request.getParameter("stock"));
            Part filePart = request.getPart("image");
            String category = request.getParameter("category");
            
            String finalPath="";
            String path = "C:/Users/graghu/Documents/Raghu/shopperden_project_team1/shopperden_project_team1/Shoppers/WebContent/produt_images";
            /*  String path= f.getAbsolutePath();
            path = path.replace("\\", "/");*/
            
            String fileName = getFileName(filePart);
            
            OutputStream out = null;
            
            InputStream filecontent = null;
              
            out = new FileOutputStream(new File(path + File.separator + fileName));
          
            filecontent = filePart.getInputStream();
            int read = 0;
            final byte[] bytes = new byte[1024 * 2];
   
            while ((read = filecontent.read(bytes)) != -1) {
            	out.write(bytes, 0, read);             
              finalPath="produt_images"+"/"+fileName;            
            }	
            
            out.flush();
            out.close();
           //Binding Data to product object 
           Product product = new Product();
           product.setBrandName(bname);
           product.setImage(finalPath);
           product.setProductDesc(pdesc);
           product.setProductPrice(price);
           product.setProductName(pname);
           product.setStock(stock);
           product.setCategory(category);
           
           //Assigning ProductImpl(c) reference to productDao(I) object
          ProductDao productDao = new ProductDaoImpl();
          //adding new product to product table by admin
          int res = productDao.saveProductInfo(product);
          if(res>0)
           {    
        	    logger.info("Product Saved successfully");
  				outObj.println("<script>alert('Product Saved successfully');\nwindow.location.href='adminhome.jsp'</script>");
	  	   }
	  	  else
	  	   {
	  		    logger.error("Failed to save Product");
	  			outObj.println("<script>alert('Failed to save Product');\nwindow.location.href='adminhome.jsp'</script>");
	  	   }
           
           
		} catch (Exception e) {
			logger.error("Error occured"+e.getMessage());
			System.out.println(e.getMessage());
		}
		
		
	
	}
}

   