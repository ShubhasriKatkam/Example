package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

/**
 * Servlet implementation class LogoutServlet
 */
//To logout from the appliation
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	final static Logger logger= Logger.getLogger(LogoutServlet.class);
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter	out = response.getWriter();
		//Fetching session object
		HttpSession session = request.getSession();
		//Destroying session object
		session.removeAttribute("usession");
		session.invalidate();
		logger.info("Successfully Logged Out ... redirecting to home page");
		out.println("<script>alert('Session Successfully Logged Out');\nwindow.location.href='shoppershome.jsp'</script>");
	
	}

}
