package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.CustomerDao;
import com.virtusa.shopping.implementations.CustomerDaoImpl;
import com.virtusa.shopping.models.Customer;

/**
 * Servlet implementation class EditAccountServlet
 */
//To update customer account
@WebServlet("/EditAccountServlet")
public class EditAccountServlet extends HttpServlet {
	final static Logger logger= Logger.getLogger(EditAccountServlet.class);
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditAccountServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
    	int res=0;
    	//fetching phoneNo from session 
    	Long phone=(Long) request.getSession(false).getAttribute("usession");
       
        PrintWriter out=response.getWriter();
        
        //Binding data to customer Object 
        Customer customer=new Customer();
        customer.setName(request.getParameter("name"));
        customer.setAddress(request.getParameter("address"));
        customer.setEmail(request.getParameter("email"));
        customer.setPassword(request.getParameter("apassword"));
        customer.setPhoneNo(phone);
        //Assigning CustomerImpl(C) reference to CustomerDao(I)
        CustomerDao dao=new CustomerDaoImpl();
    
        try
        {
           //calling update() method
           res=dao.updateCustomer(customer);
		}
        catch (SQLException e) 
        
        {
        	logger.error("Error occured"+e.getMessage());
			System.out.println("Exception : "+e.getMessage());
		}
        if(res>0)
        {
        	logger.info("customer updated profile successfully");
        	
           out.println("<script>alert('updated successfully');\nwindow.location.href='account.jsp'</script>");
        }
        else
        	logger.error("customer failed to update profile");
        	out.println("<script>alert('update is not success');\nwindow.location.href='account.jsp'</script>");	
    }

 

}
