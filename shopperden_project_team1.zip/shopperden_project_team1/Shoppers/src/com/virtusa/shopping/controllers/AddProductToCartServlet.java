package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.CartDao;
import com.virtusa.shopping.Dao.ProductDao;
import com.virtusa.shopping.exceptions.OutOfStockException;

import com.virtusa.shopping.implementations.CartDaoImpl;
import com.virtusa.shopping.implementations.ProductDaoImpl;
import com.virtusa.shopping.models.Product;
import com.virtusa.shopping.models.ProductQty;

/**
 * Servlet implementation class AddProductToCart
 */

//To add products to the cart
@WebServlet("/AddProductToCartServlet")
public class AddProductToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger= Logger.getLogger(AddProductToCartServlet.class);
	
	
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddProductToCartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		//Checking whether user is authorized or not
		HttpSession session = request.getSession(); 
		if(session.getAttribute("usession")==null)
		{
			response.getWriter().println("<script>alert(\"Cannot add item to cart..Login is required\"); window.location.href='shoppershome.jsp'</script>");
			/*response.sendRedirect("shoppershome.jsp");*/
		}
		else 
		{
			//creating object for ProductQty model class
			ProductQty productQty = new ProductQty();
			//Assigning CartImpl(C) reference to CartDao(I) Object
			CartDao cartDao=new CartDaoImpl();
			//Assigning ProductImpl(C) reference to ProductDao(I) Object
			ProductDao productDao=new ProductDaoImpl();
			//fetching the details from form
			long phoneNo = Long.parseLong(request.getParameter("phoneNo"));
			int productId = Integer.parseInt(request.getParameter("productId"));
			int qty = Integer.parseInt(request.getParameter("quantity"));
	        int cartId =0;
	        int i =0;
	        
	        PrintWriter out = response.getWriter();
	       
	        	    try {
						cartId = cartDao.getCartId(phoneNo);
						List<Product> products=productDao.getProductById(productId);
						for(Product p: products)
						{
							//binding data to the productQty Object
							  productQty.setProductId(p.getProductId()); 
							  productQty.setAmount(p.getProductPrice());
							  productQty.setCategoryId(p.getCategory());
							  productQty.setQty(qty);
							  productQty.setCartId(cartId);
							  
						}
						//calling addToCart method
						try {
						i =cartDao.addToCart(productQty) ;
						}
						catch(OutOfStockException e)
						{
							request.setAttribute("qty", e.qty);
							request.getRequestDispatcher("error.jsp").forward(request, response);
							//response.sendRedirect("error.jsp?qty="+e.qty);
							System.out.println(e);
						}
						if(i >0)
					     {
							  logger.info("Customer added product to cart");
							  out.println("<script>alert('Product Added successfully to your cart');\nwindow.location.href='userhome.jsp'</script>");
						  }
						  else
						  {
							  logger.info("Customer failed to add product to cart");
							 //response.sendRedirect("error.jsp");
							 out.println("<script>alert('Product Failed to Add to Cart');\nwindow.location.href='error.jsp'</script>");
						  }
									
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						logger.error("Error occured"+e.getMessage());
						e.printStackTrace();
						
					}
	        	  	  
	        
		  }
		}
	
}
