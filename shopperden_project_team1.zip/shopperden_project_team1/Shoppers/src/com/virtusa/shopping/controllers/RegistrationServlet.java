package com.virtusa.shopping.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.shopping.Dao.CartDao;
import com.virtusa.shopping.Dao.CustomerDao;
import com.virtusa.shopping.implementations.CartDaoImpl;
import com.virtusa.shopping.implementations.CustomerDaoImpl;
import com.virtusa.shopping.models.Customer;

/**
 * Servlet implementation class RegistrationServlet
 */

//To register the customer in the application
@WebServlet("/RegistrationServlet")
public class RegistrationServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(RegistrationServlet.class);
	 static {
         PropertyConfigurator.configure("C:\\Users\\graghu\\Documents\\Raghu\\shopperden_project_team1\\shopperden_project_team1\\Shoppers\\log4j.properties");
     } 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistrationServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		int res=0;
		Customer custom = new Customer();
		//Fetching data and Binding to Customer(C) object 
		long phone = Long.parseLong(request.getParameter("aphoneno"));
		custom.setRoleId(2);
		custom.setName(request.getParameter("name"));
		custom.setAddress(request.getParameter("address"));
		custom.setEmail(request.getParameter("email"));
		custom.setPassword(request.getParameter("apassword"));
		custom.setPhoneNo(Long.parseLong(request.getParameter("aphoneno")));
		CustomerDao c = new CustomerDaoImpl();
		PrintWriter out = response.getWriter();
		
		try
		{
		  //calling saveCustomerInfo() method
			logger.info("user Registered");
		   res = c.saveCustomerInfo(custom);
		} 
        catch (SQLException e1) 
		 {
        	logger.error("Error occured"+e1.getMessage());
		   	System.out.println("Exception  : "+e1.getMessage());
		 }		
		if(res>0)
		 {
			
			//Creating cart for Registered customer
			CartDao cartDao = new CartDaoImpl();
			try {
				logger.info("Cart is created for user");
				cartDao.createCart(phone);	
				
				out.println("<script>alert('Registred successfully'); window.location.href='shoppershome.jsp'</script>");
				
			}
			catch (SQLException e) {
				logger.error("Error occured"+e.getMessage());
				System.out.println("Exception  : "+e.getMessage());
				
			}
			
				
		 }
		
		else
		{   
			logger.error("Failed to Registred");
			out.println("<script>alert('Failed to Registred'); window.location.href='shoppershome.jsp';</script>");
		}
	}		

}
