package com.virtusa.shopping.controllers;


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import org.apache.log4j.Logger;

import com.virtusa.shopping.Dao.ProductDao;
import com.virtusa.shopping.implementations.ProductDaoImpl;
import com.virtusa.shopping.models.Product;

/**
 * Servlet implementation class UpdateServlet
 */

//To update the product details
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {
	final static Logger logger= Logger.getLogger(UpdateServlet.class);
	
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
          PrintWriter out = response.getWriter();
		
		try {
			//Fetching data 
			int pid = Integer.parseInt(request.getParameter("pid"));
			String pname = request.getParameter("pname");
			String pdesc = request.getParameter("pdesc");
			double price = Double.parseDouble(request.getParameter("price"));
			String bname = request.getParameter("brandName");
            int stock = Integer.parseInt( request.getParameter("stock"));
           
            
           //Binding Data to product Object 
           Product product = new Product();
           product.setBrandName(bname);           
           product.setProductDesc(pdesc);
           product.setProductId(pid);
           product.setProductPrice(price);
           product.setProductName(pname);
           product.setStock(stock);                    
           //Assigning ProductImpl(C) Reference to ProductDao(I) object
           ProductDao productdao = new ProductDaoImpl();
           //updating products in product table by admin
           int i = productdao.updateProduct(product);
           if(i>0){
        	   logger.info("Product updated successfully");
  				out.println("<script>alert('Product updated successfully');\nwindow.location.href='updateproducts.jsp'</script>");
	  		}
	  		else{
	  			logger.error("Failed update Product");
	  			out.println("<script>alert('Failed update Product');\nwindow.location.href='updateproducts.jsp'</script>");
	  		}
           
           
		} catch (Exception e) {
			 logger.error("Error occured"+e.getMessage());
			System.out.println(e.getMessage());
		}
		
		
	
	}
}
