package com.virtusa.shopping.controllers;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.virtusa.shopping.helpers.MySqlHelper;

/**
 * Servlet implementation class LoginServlet
 */

//To login to the application
@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	final static Logger logger= Logger.getLogger(LoginServlet.class);
	
	private static final long serialVersionUID = 1L;
	private Connection conn;
    private PreparedStatement ps;
    private ResourceBundle resourceBundle;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 //Creating DB Connection 
		 conn = MySqlHelper.getConnection();
         logger.info("Connection is Established");
         PrintWriter out =response.getWriter();
         response.setContentType("text/html");
         //Fetching Data
         Long phone =Long.parseLong(request.getParameter("phno"));
         String password =request.getParameter("password");
         resourceBundle=ResourceBundle.getBundle("com/virtusa/shopping/resources/db");
         String logQuery =resourceBundle.getString("loginQuery"); ;
         try 
          {
        	logger.info("Authenticating Credintials");
            ps = conn.prepareStatement(logQuery);    
            ps.setLong(1, phone);
            ps.setString(2, password);
            ResultSet rs =ps.executeQuery();
            if(rs.next()) 
              {
            	//To get a current session
                 HttpSession session = request.getSession();
                 
                 if(session.getAttribute("usession")==null)
                    {
                     //To assign phone no in session as usession   
                	 session.setAttribute("usession", phone);
                        //System.out.println("Session created");
                    }
                 int role =rs.getInt(1);
                 String user = rs.getString(2);
                 //To assign user name in session as UserName 
                 session.setAttribute("UserName", user);
                 
                 
                 //System.out.println(role);
                 //out.println("Login successfull");
                 if(role==2) 
                 {
                	 logger.info("Customer Logged in ");
                	 
                	 out.println("<script>alert(' Customer successfully Logged in');\nwindow.location.href='userhome.jsp'</script>");
                      
                 }
                 else 
                 {
                	logger.info("Admin Logged in "); 
                	out.println("<script>alert('Admin successfully Logged in');\nwindow.location.href='adminhome.jsp'</script>"); 
                 }
            }
            else {
            	  logger.error("User entered Wrong Credentials, login failed");
            	 out.println("<script>alert('Phone Number / Password Incorrect');\nwindow.location.href='shoppershome.jsp'</script>");
            	
            }
          } 
         catch (SQLException e) 
          {
           logger.error("Error occured"+e.getMessage());
           System.out.println("Exception : "+e.getMessage()); 
          }
    }

 

}