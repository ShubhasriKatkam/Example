package com.virtusa.shopping.Dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.exceptions.OutOfStockException;
import com.virtusa.shopping.models.ProductQty;

public interface CartDao {
	
		 //Methods for implementing cart related operations 
	    public int createCart(long phone)throws SQLException;
	    public int addToCart(ProductQty productQty)throws SQLException,OutOfStockException;
	    public int updateCart(ProductQty productQty)throws SQLException;
	    public List<ProductQty> getCart(long phoneNo)throws SQLException;	
	    public int  deleteCart(ProductQty productQty);
	    public int getCartId(long phone) throws SQLException;
	   
	}
	


