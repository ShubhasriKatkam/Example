package com.virtusa.shopping.Dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Product;

public interface ProductDao {
	
	//methods for implementing product related operations
	public int saveProductInfo(Product product) throws SQLException;
	public List<Product> getAllProducts() throws SQLException ;
	public List<Product> getProductById(int productId);
	public int  updateProduct(Product product);
	public int  deleteProduct(Product product);
}
