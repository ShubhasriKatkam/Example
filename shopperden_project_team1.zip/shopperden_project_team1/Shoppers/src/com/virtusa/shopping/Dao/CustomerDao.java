package com.virtusa.shopping.Dao;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.shopping.models.Customer;

public interface CustomerDao {
	
	//methods for implementing customer related operations
	public int saveCustomerInfo(Customer custom)throws SQLException;
	public Customer getCustomerInfo(long phone)throws SQLException;
	public int updateCustomer(Customer customer)throws SQLException ;
	 public List<Customer> getAllCustomer() throws SQLException;
}
