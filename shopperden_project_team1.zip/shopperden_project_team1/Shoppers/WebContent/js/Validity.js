window.addEventListener('load',function()
        {
	//To validate customer name
    var name = document.getElementById('name');
        name.oninvalid = function(event) {
            if(name.value === '')
                event.target.setCustomValidity('cannot be empty');
            else if(name.validity.patternMismatch)
               event.target.setCustomValidity('Name should only contain letters. e.g. Sai');
            else
                event.target.setCustomValidity('');
            return true;
        }
        //To validate phoneno
        var aphoneno= document.getElementById('aphoneno');
        aphoneno.oninvalid = function(event) {
            if(aphoneno.value === '')
                event.target.setCustomValidity('cannot be empty');
            else if(aphoneno.validity.patternMismatch)
               event.target.setCustomValidity('Phone number must contain 10 digits');
            else
                event.target.setCustomValidity('');
            return true;
        }
       
       //To validate password
        var apassword= document.getElementById('apassword');
        apassword.oninvalid = function(event) {
            if(apassword.value === '')
                event.target.setCustomValidity('cannot be empty');
            else if(apassword.validity.patternMismatch)
               event.target.setCustomValidity('Password should contain atleast one special character,one capital letter,one number and password should contain 8-10 characters');
            else
                event.target.setCustomValidity('');
            return true;
        }
            var form=document.getElementById("RegistrationForm")
             form.addEventListener("submit",function(){
                var xhr=null;
                //create ajax object                
                 try
                 {
                     xhr= new XMLHttpRequest(); //chrome,safari,firefox                    
                 }
                 catch(err)
                 {
                     try
                     {
                     xhr = new ActiveXObject("MSXML2.XMLHttp.6.0"); //IE
                     }
                     catch(err)
                     {
                         console.log("Ajax Object not created");
                     }
                 }
                 //Ajax Event handling 
                //once response received from server
                xhr.onreadystatechange = function()
                 {
                    
                     var response=null;
                     if (xhr.readyState == 4)//successful response
                         {
                          response=xhr.responseText;
                          alert(response);
                          /*document.getElementById("result").innerHTML=response;*/
                         }          
                 }

 

                 //open the connection
                 xhr.open('post','RegistrationServlet',false);
                 xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                //read values from form
                var name = document.getElementById("name").value;
                var address = document.getElementById("address").value;                                
                var email =document.getElementById("email").value;
                var apassword =document.getElementById("apassword").value;
                var aphoneno = document.getElementById("aphoneno").value;
               //Sending the data to servlet
                xhr.send("name="+name+"&aphoneno="+aphoneno+"&email="+email+"&apassword="+apassword+"&address="+address);
                return false;
            });
                   
            
            return false;
        }

 

        )