window.addEventListener('load',function()
        {
     //To validate customer name
    var name = document.getElementById('name');
        name.oninvalid = function(event) {
            if(name.value === '')
                event.target.setCustomValidity('cannot be empty');
            else if(name.validity.patternMismatch)
               event.target.setCustomValidity('Name should only contain letters. e.g. Sai');
            else
                event.target.setCustomValidity('');
            return true;
        }
       
       
       //To validate the password
        var apassword= document.getElementById('apassword');
        apassword.oninvalid = function(event) {
            if(apassword.value === '')
                event.target.setCustomValidity('cannot be empty');
            else if(apassword.validity.patternMismatch)
               event.target.setCustomValidity('Password should contain atleast one special character,one capital letter,one number and password should contain 8-10 characters');
            else
                event.target.setCustomValidity('');
            return true;
        }
  
            
        return false;
    }

 

        )