DELIMITER $$

DROP PROCEDURE IF EXISTS updateProductQty $$
CREATE PROCEDURE updateProductQty(in p_productQtyId INTEGER,in p_qty INTEGER) 

BEGIN
 
update productqtyteam1 set Qty=p_qty where productQtyId=p_productQtyId;
END $$

DELIMITER ;