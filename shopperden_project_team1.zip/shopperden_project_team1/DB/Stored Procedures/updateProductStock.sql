DELIMITER $$

DROP PROCEDURE IF EXISTS updateProductStock $$
CREATE PROCEDURE updateProductStock(in p_stock INTEGER,in p_productId INTEGER) 
BEGIN
 
update productTeam1 set stock=p_stock where productId=p_productId;
END $$

DELIMITER ;
