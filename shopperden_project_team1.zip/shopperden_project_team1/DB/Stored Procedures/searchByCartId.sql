DELIMITER $$
DROP PROCEDURE IF EXISTS searchByCartId $$
CREATE PROCEDURE searchByCartId(IN p_phoneno bigint)
BEGIN
select * from productqtyteam1 where cartId=(select cartId from cartteam1 where phoneNo=p_phoneno);
END $$

DELIMITER ;