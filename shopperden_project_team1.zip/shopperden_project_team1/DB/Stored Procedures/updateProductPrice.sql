DELIMITER $$

DROP PROCEDURE IF EXISTS updateProductPrice $$
CREATE PROCEDURE updateProductPrice(in p_price INTEGER,in p_productId INTEGER) 
BEGIN
 
update productTeam1 set price=p_price where productId=p_productId;
END $$

DELIMITER ;
