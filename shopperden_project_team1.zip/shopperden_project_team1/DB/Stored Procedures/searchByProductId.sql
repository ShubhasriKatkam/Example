DELIMITER $$

 

 

 

DROP PROCEDURE IF EXISTS searchByProductId $$
CREATE PROCEDURE searchByProductId(IN p_productId INTEGER)

 

 

 

BEGIN

 

 

 

select * from productteam1 where productId=p_productId;
END $$

 

 

 

DELIMITER ;