DELIMITER $$

DROP PROCEDURE IF EXISTS searchByPrice $$
CREATE PROCEDURE searchByPrice(IN min INTEGER,IN max INTEGER, OUT p_productId INTEGER ,OUT p_productDesc varchar(100),OUT p_brandName varchar(25),OUT p_productName varchar(100),OUT p_price integer,OUT p_stock integer)
BEGIN
select productId,productDesc,brandName,price ,stock into p_productId ,p_productName ,p_productDesc ,p_brandName ,p_price ,p_stock from productteam1 where price<max and price>min;
END $$

DELIMITER ;
