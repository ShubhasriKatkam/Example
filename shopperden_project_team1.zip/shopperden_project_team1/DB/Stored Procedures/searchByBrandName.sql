DELIMITER $$

DROP PROCEDURE IF EXISTS searchByBrandName $$
CREATE PROCEDURE searchByBrandName(IN p_brandName varchar(25) , OUT p_productId INTEGER ,OUT p_productDesc varchar(100),OUT p_productName varchar(45),OUT p_price integer,OUT p_stock integer)
BEGIN
select productId,productDesc,brandName,price ,stock into p_productId ,p_productName ,p_productDesc ,p_brandName ,p_price ,p_stock from productteam1 where brandName=p_brandName;
END $$

DELIMITER ;
