DELIMITER $$

DROP PROCEDURE IF EXISTS updateUserAddress $$
CREATE PROCEDURE updateUserAddress(in u_address varchar(50),in u_phoneNo bigint(20)) 

BEGIN
 
update userteam1 set address=u_address where phoneNo=u_phoneNo;
END $$

DELIMITER ;

 