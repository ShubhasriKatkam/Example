DELIMITER $$

DROP PROCEDURE IF EXISTS addProduct $$
CREATE PROCEDURE addProduct(in p_productId INTEGER,in p_productName VARCHAR(45),
in p_dop DATETIME,in p_cost INTEGER, in p_catId INTEGER)

BEGIN
insert into productTeam1 values(p_productId,p_productName,p_dop,p_cost,p_catId);

END $$

DELIMITER ;

