
DELIMITER $$
DROP PROCEDURE IF EXISTS selectAllProducts $$CREATE PROCEDURE selectAllProducts( )
BEGIN
select * from productteam1;
END $$

DELIMITER ;
