DELIMITER $$

DROP PROCEDURE IF EXISTS updateUserEmail $$
CREATE PROCEDURE updateUserEmail(in u_email varchar(40),in u_phoneNo bigint(20)) 

BEGIN
 
update userteam1 set email=u_email where phoneNo=u_phoneNo;
END $$

DELIMITER ;

 