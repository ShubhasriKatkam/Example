DELIMITER $$

DROP PROCEDURE IF EXISTS deleteCategory $$
CREATE PROCEDURE deleteCategory(in c_categoryId INTEGER) 
BEGIN
 
delete from categoryteam1  where categoryId=c_categoryId;
END $$

DELIMITER ;