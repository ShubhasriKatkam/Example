DELIMITER $$

DROP PROCEDURE IF EXISTS deleteProductQty $$
CREATE PROCEDURE deleteProductQty(in p_productId INTEGER) 
BEGIN
 
delete from productqtyteam1  where productId=p_productId;
END $$

DELIMITER ;