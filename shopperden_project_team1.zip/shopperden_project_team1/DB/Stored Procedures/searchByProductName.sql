DELIMITER $$
DROP PROCEDURE IF EXISTS searchByProductName $$
CREATE PROCEDURE searchByProductName(IN p_productName varchar(45) , OUT p_productId INTEGER ,OUT p_productDesc varchar(100),OUT p_brandName varchar(25),OUT p_price integer,OUT p_stock integer)
BEGIN
select productId,productDesc,brandName,price ,stock into p_productId ,p_productName ,p_productDesc ,p_brandName ,p_price ,p_stock from productteam1 where productName=p_productName;
END $$

DELIMITER ;