DELIMITER $$

DROP PROCEDURE IF EXISTS addcartteam1 $$
CREATE PROCEDURE addcartteam1(in c_cartId INTEGER,in c_phoneNo bigint)
BEGIN
 insert into cartteam1 values(c_cartId,c_phoneNo);
END $$

DELIMITER ;